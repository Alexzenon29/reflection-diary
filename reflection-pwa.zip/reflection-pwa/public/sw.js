const CACHE_NAME = 'reflection-app-v2'; // Я изменил версию, чтобы обновить кэш

const ASSETS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.json',
  
  // Библиотеки
  './libs/lucide.js',

  // Логика
  './domain/utils.js',
  './domain/forms.service.js',
  './domain/entries.service.js',
  './domain/export.service.js',
  
  // Хранилище
  './storage/storage.indexeddb.js',
  
  // Интерфейс
  './ui/components.js',
  './ui/screens.js',
  // './ui/validators.js', // ЗАКОММЕНТИРУЙ, если этого файла физически нет!
  
  // Иконка
  // './icon-192.png' // ЗАКОММЕНТИРУЙ, если файла нет, иначе PWA сломается!
];

// 1. Установка: Попытка закэшировать
self.addEventListener('install', (event) => {
  console.log('[SW] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Мы пробуем добавлять файлы по одному, чтобы видеть ошибку
      console.log('[SW] Caching assets...');
      try {
        await cache.addAll(ASSETS);
        console.log('[SW] All assets cached successfully!');
      } catch (err) {
        console.error('[SW] Cache failed! Check your file list. Error:', err);
      }
    })
  );
});

// 2. Активация: Чистка старого кэша
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating...');
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[SW] Removing old cache:', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  return self.clients.claim();
});

// 3. Перехват запросов
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      // Если есть в кэше - отдаем
      if (cachedResponse) {
        return cachedResponse;
      }
      // Если нет - пробуем скачать (и если офлайн, тут упадет)
      return fetch(event.request).catch(() => {
        // Здесь можно вернуть заглушку, если сети нет
        console.warn('[SW] Fetch failed (offline) and not in cache:', event.request.url);
      });
    })
  );
});
