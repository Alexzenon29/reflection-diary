export class Router {
  constructor(routes) {
    this.routes = routes; // { '/home': renderHome, '/journal': renderJournal, ... }
    this.appTitle = document.getElementById("header-title");
    this.navItems = document.querySelectorAll(".nav-item");
    
    window.addEventListener("hashchange", () => this.handleRoute());
    window.addEventListener("load", () => this.handleRoute());
  }

  handleRoute() {
    let hash = window.location.hash.slice(1) || "/home"; // убираем #
    
    // Обработка параметров (например /fill/f_morning)
    // Ищем подходящий маршрут (простой regex или startsWith)
    let matchedRoute = null;
    let params = null;

    // Сначала точное совпадение
    if (this.routes[hash]) {
      matchedRoute = hash;
    } else {
      // Иначе ищем маршруты с параметрами (пока просто /fill/)
      if (hash.startsWith("/fill/")) {
        matchedRoute = "/fill/:id";
        params = hash.split("/")[2];
      }
    }

    if (!matchedRoute || !this.routes[matchedRoute]) {
      // 404 -> Home
      window.location.hash = "/home";
      return;
    }

    // Обновляем активную вкладку в меню
    this.updateNav(hash);

    // Запускаем рендер экрана
    const renderFn = this.routes[matchedRoute];
    renderFn(params);
  }

  updateNav(hash) {
    // Простая логика подсветки меню
    // Если мы на /fill/..., меню может не подсвечиваться или подсвечивать Home
    const baseHash = hash.split("/")[1]; // home, journal, forms
    
    this.navItems.forEach(item => {
      const target = item.getAttribute("data-target");
      if (target === baseHash) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }
    });
  }

  setTitle(title) {
    if (this.appTitle) this.appTitle.textContent = title;
  }
}
