const DB_NAME = "reflection_pwa";
const DB_VERSION = 1;

const STORES = {
  forms: "forms",
  entries: "entries",
  settings: "settings",
  meta: "meta"
};

function reqToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function openDb() {
  const request = indexedDB.open(DB_NAME, DB_VERSION);

  request.onupgradeneeded = (event) => {
    const db = request.result;

    if (!db.objectStoreNames.contains(STORES.forms)) {
      db.createObjectStore(STORES.forms, { keyPath: "id" });
    }

    if (!db.objectStoreNames.contains(STORES.entries)) {
      const store = db.createObjectStore(STORES.entries, { keyPath: "id" });
      store.createIndex("byTimestamp", "timestamp");
      store.createIndex("byFormId", "formId");
    }

    if (!db.objectStoreNames.contains(STORES.settings)) {
      db.createObjectStore(STORES.settings, { keyPath: "key" });
    }

    if (!db.objectStoreNames.contains(STORES.meta)) {
      db.createObjectStore(STORES.meta, { keyPath: "key" });
    }
  };

  const db = await reqToPromise(request);

  db.onversionchange = () => {
    db.close();
    console.warn("DB version changed in another tab. Please reload.");
  };

  return db;
}

export class IDBStorage {
  constructor(db) {
    this.db = db;
  }

  async get(storeName, key) {
    const tx = this.db.transaction([storeName], "readonly");
    const store = tx.objectStore(storeName);
    const value = await reqToPromise(store.get(key));
    await txDone(tx);
    return value ?? null;
  }

  async getAll(storeName) {
    const tx = this.db.transaction([storeName], "readonly");
    const store = tx.objectStore(storeName);
    const value = await reqToPromise(store.getAll());
    await txDone(tx);
    return value;
  }

  async put(storeName, value) {
    const tx = this.db.transaction([storeName], "readwrite");
    const store = tx.objectStore(storeName);
    await reqToPromise(store.put(value));
    await txDone(tx);
  }

  async delete(storeName, key) {
    const tx = this.db.transaction([storeName], "readwrite");
    const store = tx.objectStore(storeName);
    await reqToPromise(store.delete(key));
    await txDone(tx);
  }

  async clear(storeName) {
    const tx = this.db.transaction([storeName], "readwrite");
    const store = tx.objectStore(storeName);
    await reqToPromise(store.clear());
    await txDone(tx);
  }

  async getEntriesByTimeRange(fromTs, toTs) {
    const tx = this.db.transaction([STORES.entries], "readonly");
    const store = tx.objectStore(STORES.entries);
    const idx = store.index("byTimestamp");
    const range = IDBKeyRange.bound(fromTs, toTs);
    const result = await reqToPromise(idx.getAll(range));
    await txDone(tx);
    return result;
  }
}

export { STORES, DB_NAME, DB_VERSION };
