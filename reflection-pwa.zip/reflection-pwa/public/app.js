import { openDb, IDBStorage } from "./storage/storage.indexeddb.js";
import { FormsService } from "./domain/forms.service.js";
import { EntriesService } from "./domain/entries.service.js";
import { ExportService } from "./domain/export.service.js"; // <-- НОВОЕ
import { Router } from "./router.js";
import { renderHome, renderFillForm, renderJournal, renderFormsList } from "./ui/screens.js";

window.App = {
  db: null,
  services: {}
};

window.addEventListener('DOMContentLoaded', () => {
  initApp();
});

async function initApp() {
  try {
    const db = await openDb();
    const storage = new IDBStorage(db);
    
    const formsService = new FormsService(storage);
    const entriesService = new EntriesService(storage, formsService);
    const exportService = new ExportService(storage); // <-- НОВОЕ
    
    window.App.services = {
      forms: formsService,
      entries: entriesService,
      export: exportService // <-- НОВОЕ
    };

    await formsService.importDefaultFormsIfEmpty();

    window.router = new Router({
      "/home": renderHome,
      "/journal": renderJournal,
      "/forms": renderFormsList,
      "/fill/:id": renderFillForm
    });

  } catch (err) {
    document.body.innerHTML = "Ошибка запуска: " + err.message;
  }
}
