import { openDb, IDBStorage } from "./storage/storage.indexeddb.js";
import { FormsService } from "./domain/forms.service.js";
import { EntriesService } from "./domain/entries.service.js";

async function bootstrap() {
  const db = await openDb();
  const storage = new IDBStorage(db);

  const forms = new FormsService(storage);
  const entries = new EntriesService(storage, forms);

  await forms.importDefaultFormsIfEmpty();

  window.Diary = {
    storage,
    forms,
    entries,
    help() {
      console.log("Diary.forms.listForms()");
      console.log("Diary.forms.createForm({title:'Test', scheduleLabel:'', sortOrder:99})");
      console.log("Diary.forms.addQuestion(formId, {type:'text', label:'Что чувствуешь?', required:true})");
      console.log("Diary.entries.createEntry(formId, { [questionId]:'ответ', ... })");
      console.log("Diary.entries.listEntries()");
    }
  };

  console.log("Ready. Try: Diary.help()");
}

bootstrap().catch(console.error);
