﻿export const Components = {
  // Карточка формы
  formCard: (form) => `
    <a href="#/fill/${form.id}" class="card form-card-clickable" style="display:block; text-decoration:none; color:inherit; margin-bottom:12px; border-left: 4px solid var(--accent-color);">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div style="font-weight:600; font-size:16px; display:flex; align-items:center; gap:8px;">
            ${form.title}
          </div>
          <div class="text-sm" style="display:flex; align-items:center; gap:4px; opacity:0.7;">
             <i data-lucide="clock" style="width:12px; height:12px;"></i>
             ${form.scheduleLabel || "По запросу"}
          </div>
        </div>
        <div style="background:var(--bg-elevated); padding:8px; border-radius:50%;">
           <i data-lucide="play" style="width:16px; height:16px; fill:currentColor;"></i>
        </div>
      </div>
    </a>
  `,

  sectionHeader: (text) => `
    <h4 style="margin: 24px 0 12px 0; opacity:0.5; font-size:11px; text-transform:uppercase; letter-spacing:1px; display:flex; align-items:center; gap:8px;">
      ${text}
      <div style="flex:1; height:1px; background:#333;"></div>
    </h4>
  `,

  journalItem: (entry) => {
    const date = new Date(entry.timestamp);
    const timeStr = date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    
    // Парсим ответы
    let feeling = "—";
    let energy = "—";
    
    if (entry.questionSnapshots) {
      entry.questionSnapshots.forEach(q => {
        const val = entry.answers[q.id];
        if (!val) return;
        const l = q.label.toLowerCase();
        if (l.includes("чувств")) feeling = val;
        if (l.includes("энергия")) energy = val;
      });
    }

    return `
      <div class="card" style="margin-bottom:12px; padding:12px; border-left: 2px solid #333;">
        <div style="display:flex; justify-content:space-between; font-size:12px; opacity:0.6; margin-bottom:6px;">
          <span style="display:flex; align-items:center; gap:4px;">
            <i data-lucide="clock" style="width:12px;"></i> ${timeStr} • ${entry.formTitle}
          </span>
        </div>
        <div style="font-size:15px; margin-bottom:6px; font-weight:500;">${feeling}</div>
        <div style="font-size:12px; display:flex; gap:12px;">
           <span style="display:flex; align-items:center; gap:4px;"><i data-lucide="zap" style="width:12px; color:yellow;"></i> ${energy}</span>
        </div>
      </div>
    `;
  },

  energyChart: (entries) => {
    const today = new Date().toDateString();
    const data = entries
      .filter(e => new Date(e.timestamp).toDateString() === today)
      .map(e => {
        let val = 0;
        if(e.questionSnapshots) {
            const q = e.questionSnapshots.find(x => x.label.toLowerCase().includes("энергия"));
            if(q && e.answers[q.id]) val = parseInt(e.answers[q.id]);
        }
        return { time: e.timestamp, val };
      })
      .filter(d => d.val > 0)
      .sort((a,b) => a.time - b.time);

    if (data.length < 2) return ``;

    const width = 300, height = 80;
    const maxVal = 10;
    const startTime = data[0].time;
    const endTime = data[data.length-1].time;
    const duration = endTime - startTime || 1;

    const points = data.map(d => {
      const x = ((d.time - startTime) / duration) * width;
      const y = height - ((d.val / maxVal) * height);
      return `${x},${y}`;
    }).join(" ");

    return `
      <div class="card" style="padding:16px;">
        <div class="text-sm" style="margin-bottom:12px; display:flex; gap:6px;">
            <i data-lucide="activity" style="width:14px;"></i> Энергия сегодня
        </div>
        <svg width="100%" height="${height}" viewBox="0 0 ${width} ${height}" style="overflow:visible;">
          <polyline fill="none" stroke="var(--accent-color)" stroke-width="2" points="${points}" />
          ${data.map(d => {
             const x = ((d.time - startTime) / duration) * width;
             const y = height - ((d.val / maxVal) * height);
             return `<circle cx="${x}" cy="${y}" r="3" fill="#fff" />`;
          }).join('')}
        </svg>
      </div>
    `;
  },

  // Умные теги в зависимости от текста вопроса
  getTagsForQuestion: (label) => {
    const l = label.toLowerCase();
    if (l.includes("чувств") || l.includes("настроение")) return ['Спокойствие', 'Тревога', 'Радость', 'Усталость', 'Скука', 'Раздражение'];
    if (l.includes("занимаешься") || l.includes("дело")) return ['Работа', 'Отдых', 'Еда', 'Спорт', 'Учеба', 'В дороге'];
    if (l.includes("мешает") || l.includes("помехи")) return ['Шум', 'Мысли', 'Телефон', 'Ничего', 'Коллеги'];
    if (l.includes("спал")) return ['Отлично', 'Норм', 'Плохо', 'Мало', 'Много'];
    return ['Да', 'Нет', 'Не знаю']; // Дефолт
  },
  
  // Иконки для типов вопросов
  getTypeIcon: (type) => {
      if (type === 'text') return 'align-left'; // lucide name
      if (type === 'range') return 'sliders-horizontal';
      if (type === 'yesno') return 'check-square';
      return 'help-circle';
  }
};