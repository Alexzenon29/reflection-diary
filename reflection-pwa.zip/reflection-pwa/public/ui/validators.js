export const Validators = {
  validateEntry(form, answers) {
    const errors = {};
    let isValid = true;

    form.questions.forEach(q => {
      const val = answers[q.id];
      
      // 1. Обязательное поле
      if (q.required) {
        if (val === undefined || val === "" || val === null) {
          errors[q.id] = "Обязательное поле";
          isValid = false;
        }
      }

      // 2. Валидация шкалы (range)
      if (q.type === 'range' && val !== undefined) {
        const num = Number(val);
        if (num < (q.min || 1) || num > (q.max || 10)) {
          errors[q.id] = `Значение должно быть от ${q.min} до ${q.max}`;
          isValid = false;
        }
      }
    });

    return { isValid, errors };
  }
};
