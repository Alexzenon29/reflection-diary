﻿import { Components } from "./components.js";

// Утилита для обновления иконок
const refreshIcons = () => setTimeout(() => window.lucide && window.lucide.createIcons(), 50);

// =============================================================================
// 1. ГЛАВНАЯ СТРАНИЦА
// =============================================================================
export async function renderHome() {
  const forms = await window.App.services.forms.listForms();
  const entries = await window.App.services.entries.listEntries();
  const container = document.getElementById("app");
  window.router.setTitle("Сегодня");

  const sorted = forms.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));

  let html = `<div style="padding-bottom: 80px;">`;
  html += Components.energyChart(entries);
  html += Components.sectionHeader("Заполнить отчет");

  // Защита от пустого экрана
  if (sorted.length === 0) {
    html += `
      <div class="card text-center" style="padding:32px 16px;">
        <i data-lucide="folder-open" style="width:48px; height:48px; opacity:0.2; margin-bottom:16px;"></i>
        <div style="margin-bottom:16px; font-size:15px;">Список форм пуст.</div>
        <button id="btn-restore-defaults" class="btn btn-block" style="background:var(--accent-color); color:#000;">
           Восстановить стандартные формы
        </button>
      </div>
    `;
  } else {
    sorted.forEach(f => {
      html += Components.formCard(f);
    });
  }
  html += `</div>`;
  container.innerHTML = html;
  refreshIcons();

  // Логика кнопки восстановления
  const btnRestore = document.getElementById('btn-restore-defaults');
  if (btnRestore) {
    btnRestore.onclick = async () => {
      btnRestore.textContent = "Загрузка...";
      await window.App.services.forms.importDefaultFormsIfEmpty();
      renderHome();
    };
  }
}

// =============================================================================
// 2. ЗАПОЛНЕНИЕ ФОРМЫ
// =============================================================================
export async function renderFillForm(formId) {
  const form = await window.App.services.forms.getForm(formId);
  const entries = await window.App.services.entries.listEntries();
  const container = document.getElementById("app");
  
  if (!form) return container.innerHTML = "Ошибка: Форма не найдена";
  window.router.setTitle(form.title);

  const lastEntry = entries[0];
  let html = `<form id="entry-form" style="padding-bottom: 140px;">`; 
  
  // Кнопка копирования предыдущего ответа
  if (lastEntry) {
      html += `<button type="button" id="btn-copy" class="btn btn-outline btn-block" style="margin-bottom:20px; border-style:dashed;">
         <i data-lucide="copy" style="width:14px; margin-right:8px;"></i> Копировать прошлый ответ
      </button>`;
  }

  form.questions.forEach((q, idx) => {
    const autofocus = idx === 0 ? 'autofocus' : '';
    html += `<div class="card form-group" data-qid="${q.id}">
      <label class="form-label">${q.label}</label>`;

    if (q.type === 'text') {
      const tags = Components.getTagsForQuestion(q.label);
      html += `
        <input type="text" name="${q.id}" id="inp-${q.id}" class="input-text" ${autofocus} autocomplete="off">
        <div style="display:flex; gap:8px; margin-top:12px; flex-wrap:wrap;">
           ${tags.map(tag => `<span class="tag-preset" data-target="inp-${q.id}" style="background:var(--bg-primary); border:1px solid #333; padding:6px 12px; border-radius:20px; font-size:12px; cursor:pointer;">${tag}</span>`).join('')}
        </div>`;
    } else if (q.type === 'range') {
      html += `
        <div style="display:flex; align-items:center; gap:16px;">
          <input type="range" name="${q.id}" id="inp-${q.id}" min="1" max="10" step="1" value="5" oninput="this.nextElementSibling.textContent = this.value" style="flex:1">
          <div style="font-weight:700; color:var(--accent-color); font-size:20px; width:24px; text-align:center;">5</div>
        </div>`;
    } else if (q.type === 'yesno') {
       html += `
         <div style="display:flex; gap:12px;">
            <label style="flex:1; cursor:pointer"><input type="radio" name="${q.id}" value="Да" class="hidden peer"><div class="btn btn-outline btn-block radio-ui">Да</div></label>
            <label style="flex:1; cursor:pointer"><input type="radio" name="${q.id}" value="Нет" class="hidden peer"><div class="btn btn-outline btn-block radio-ui">Нет</div></label>
         </div>
         <style>.peer:checked + .radio-ui { background:var(--accent-color); color:#000; border-color:var(--accent-color); }</style>`;
    }
    html += `</div>`;
  });

  // Плавающая кнопка сохранения
  html += `
    <div style="position:fixed; bottom:var(--nav-height); left:0; right:0; padding:16px; background:rgba(18,18,18,0.95); z-index:99; padding-bottom:calc(16px + env(safe-area-inset-bottom)); border-top:1px solid rgba(255,255,255,0.1);">
      <button type="submit" class="btn btn-block" style="box-shadow: 0 4px 20px rgba(187,134,252,0.25);">
         <i data-lucide="save" style="margin-right:8px; width:18px;"></i> Сохранить запись
      </button>
    </div>
  </form>`;

  container.innerHTML = html;
  refreshIcons();

  // Логика тегов
  document.querySelectorAll('.tag-preset').forEach(tag => {
    tag.onclick = () => {
      const el = document.getElementById(tag.dataset.target);
      if (el) el.value = tag.innerText;
    };
  });

  // Логика копирования
  const btnCopy = document.getElementById('btn-copy');
  if (btnCopy) {
    btnCopy.onclick = () => {
      form.questions.forEach(q => {
        const val = lastEntry.answers[q.id];
        if (val) {
          const el = document.getElementById(`inp-${q.id}`);
          if (el) {
            el.value = val;
            if (el.nextElementSibling && el.type === 'range') {
               el.nextElementSibling.textContent = val;
            }
          }
        }
      });
    };
  }
  
  // Сабмит формы
  const formEl = document.getElementById("entry-form");
  formEl.onsubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(formEl);
    const answers = {};
    form.questions.forEach(q => {
      const v = formData.get(q.id);
      if (v) answers[q.id] = v.trim();
    });
    try {
      await window.App.services.entries.createEntry(form.id, answers);
      window.location.hash = "/journal";
    } catch (err) {
      alert(err.message);
    }
  };
}

// =============================================================================
// 3. ЖУРНАЛ
// =============================================================================
export async function renderJournal() {
  const entries = await window.App.services.entries.listEntries();
  const container = document.getElementById("app");
  window.router.setTitle("Журнал");
  
  let html = `<div style="padding-bottom:80px;">`;
  html += Components.energyChart(entries);
  html += Components.sectionHeader("История");
  
  if (entries.length === 0) {
    html += `<div class="text-center text-sm" style="margin-top:20px;">Пока пусто</div>`;
  } else {
    entries.forEach(e => html += Components.journalItem(e));
  }
  
  html += `</div>`;
  container.innerHTML = html;
  refreshIcons();
}

// =============================================================================
// 4. НАСТРОЙКИ И ИМПОРТ
// =============================================================================
export async function renderFormsList() {
  const forms = await window.App.services.forms.listForms();
  const container = document.getElementById("app");
  window.router.setTitle("Настройки");

  let html = `<div style="padding-bottom:80px;">`;
  html += Components.sectionHeader("Мои формы");
  html += `<div id="forms-list">`;
  
  forms.forEach(f => {
    html += `
      <div class="card" style="display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:12px;">
            <i data-lucide="file-text" style="width:18px; opacity:0.5;"></i>
            <div>
               <div style="font-weight:600; font-size:15px;">${f.title}</div>
               <div class="text-sm" style="opacity:0.5; font-size:11px;">${f.questions.length} вопросов</div>
            </div>
        </div>
        <div style="display:flex; gap:8px;">
           <button class="btn btn-outline btn-dup" data-id="${f.id}" style="width:40px; padding:0;" title="Дублировать"><i data-lucide="copy" style="width:16px;"></i></button>
           <button class="btn btn-outline btn-edit" data-id="${f.id}" style="width:40px; padding:0;" title="Изменить"><i data-lucide="settings-2" style="width:16px;"></i></button>
        </div>
      </div>`;
  });
  html += `</div>`;
  
  html += `<button id="btn-add" class="btn btn-outline btn-block" style="border-style:dashed; opacity:0.7;">+ Создать новую форму</button>`;

  // СЕКЦИЯ ДАННЫХ
  html += Components.sectionHeader("Данные и Импорт");
  html += `<div class="card">
     <!-- КНОПКА ИМПОРТА JSON -->
     <input type="file" id="inp-import-json" accept=".json" style="display:none">
     <button id="btn-import-json" class="btn btn-block" style="margin-bottom:12px; justify-content:flex-start; background:var(--bg-elevated); color:var(--text-primary); border:1px solid #444;">
        <i data-lucide="upload" style="margin-right:12px; width:18px;"></i> Импорт конфига (JSON)
     </button>

     <button id="btn-csv" class="btn btn-block" style="margin-bottom:12px; justify-content:flex-start;">
        <i data-lucide="download" style="margin-right:12px; width:18px;"></i> Скачать CSV
     </button>
     
     <div style="height:1px; background:#333; margin:16px 0;"></div>
     
     <button id="btn-clear-j" class="btn btn-outline btn-block" style="border-color:var(--error-color); color:var(--error-color); margin-bottom:12px; justify-content:flex-start;">
        <i data-lucide="trash-2" style="margin-right:12px; width:18px;"></i> Очистить журнал
     </button>
     
     <button id="btn-reset" class="btn btn-block" style="background:var(--error-color); justify-content:flex-start;">
        <i data-lucide="alert-triangle" style="margin-right:12px; width:18px;"></i> Полный сброс приложения
     </button>
  </div>`;
  
  html += `</div>`;
  container.innerHTML = html;
  refreshIcons();

  // --- Обработчики кнопок настроек ---

  document.querySelectorAll('.btn-edit').forEach(b => {
      b.onclick = () => renderFormEditor(b.dataset.id);
  });
  
  document.querySelectorAll('.btn-dup').forEach(b => {
      b.onclick = async () => {
          await window.App.services.forms.duplicateForm(b.dataset.id);
          renderFormsList();
      };
  });
  
  document.getElementById('btn-add').onclick = async () => {
      const title = prompt("Название:");
      if (title) {
          await window.App.services.forms.createForm({ title });
          renderFormsList();
      }
  };
  
  // Логика импорта JSON
  const btnImport = document.getElementById('btn-import-json');
  const inpImport = document.getElementById('inp-import-json');
  
  if (btnImport && inpImport) {
      btnImport.onclick = () => inpImport.click();
      inpImport.onchange = async (e) => {
          const file = e.target.files[0];
          if (!file) return;
          
          const reader = new FileReader();
          reader.onload = async (evt) => {
              try {
                  const json = JSON.parse(evt.target.result);
                  if (confirm(`Загрузить формы из файла? Найдено: ${json.forms?.length || 0} шт.`)) {
                      await window.App.services.forms.importFromJSON(json);
                      alert("Импорт завершен!");
                      renderFormsList();
                  }
              } catch (err) {
                  alert("Ошибка чтения JSON: " + err.message);
              }
          };
          reader.readAsText(file);
      };
  }

  document.getElementById('btn-clear-j').onclick = async () => {
      if (confirm("Удалить записи?")) {
          const db = window.App.db;
          const tx = db.transaction("entries", "readwrite");
          await tx.objectStore("entries").clear();
          renderFormsList();
      }
  };
  
  document.getElementById('btn-csv').onclick = async () => {
      const csv = await window.App.services.export.createCSV();
      if (csv) {
          window.App.services.export.downloadFile(csv, "diary.csv", "text/csv");
      }
  };
  
  document.getElementById('btn-reset').onclick = async () => {
      if (confirm("ВНИМАНИЕ: Удалить ВСЕ данные и формы?")) {
          const db = window.App.db;
          const tx = db.transaction(db.objectStoreNames, "readwrite");
          for (const s of db.objectStoreNames) tx.objectStore(s).clear();
          tx.oncomplete = () => window.location.reload();
      }
  };
}

// =============================================================================
// 5. РЕДАКТОР ФОРМЫ (Смена названий и типов вопросов)
// =============================================================================
async function renderFormEditor(formId) {
  const form = await window.App.services.forms.getForm(formId);
  const container = document.getElementById("app");
  if (!form) return renderFormsList();
  window.router.setTitle(`Ред: ${form.title}`);

  let html = `<div style="padding-bottom:100px;">`;
  html += `<button id="btn-back" class="btn btn-outline" style="margin-bottom:16px;">← Назад</button>`;
  
  // Редактирование шапки
  html += `<div class="card">
     <label class="form-label">Название формы</label>
     <input id="edit-title" class="input-text" value="${form.title}" style="margin-bottom:16px;">
     <label class="form-label">Время / Подзаголовок</label>
     <input id="edit-time" class="input-text" value="${form.scheduleLabel || ''}">
     <button id="btn-save-meta" class="btn btn-block" style="margin-top:16px;">Сохранить шапку</button>
  </div>`;

  html += Components.sectionHeader("Вопросы");
  
  form.questions.forEach((q) => {
    html += `
      <div class="card">
        <div style="display:flex; flex-direction:column; gap:8px; margin-bottom:12px;">
           <!-- Ряд 1: Текст и Кнопки -->
           <div style="display:flex; gap:8px;">
              <input class="input-text edit-q-label" data-qid="${q.id}" value="${q.label}" style="flex:1;">
              <button class="btn btn-outline btn-move" data-qid="${q.id}" data-dir="up" style="width:36px;"><i data-lucide="arrow-up" style="width:14px;"></i></button>
              <button class="btn btn-outline btn-move" data-qid="${q.id}" data-dir="down" style="width:36px;"><i data-lucide="arrow-down" style="width:14px;"></i></button>
              <button class="btn btn-outline btn-del" data-qid="${q.id}" style="color:var(--error-color); border-color:var(--error-color); width:36px;"><i data-lucide="trash-2" style="width:14px;"></i></button>
           </div>
           
           <!-- Ряд 2: Тип вопроса -->
           <div style="display:flex; align-items:center; gap:8px;">
               <span class="text-sm">Тип:</span>
               <select class="input-text q-type-selector" data-qid="${q.id}" style="height:36px; padding:0 12px; font-size:13px; width:auto; flex:1;">
                  <option value="text" ${q.type === 'text' ? 'selected' : ''}>Текст</option>
                  <option value="range" ${q.type === 'range' ? 'selected' : ''}>Шкала (1-10)</option>
                  <option value="yesno" ${q.type === 'yesno' ? 'selected' : ''}>Да / Нет</option>
               </select>
           </div>
        </div>
      </div>`;
  });

  // Добавление нового вопроса
  html += `
  <div class="card" style="border:1px dashed #555; background:transparent;">
    <div style="display:flex; gap:8px;">
       <input id="new-q-text" class="input-text" placeholder="Текст нового вопроса" style="flex:1;">
       <select id="new-q-type" class="input-text" style="width:100px;">
          <option value="text">Текст</option>
          <option value="range">Шкала</option>
          <option value="yesno">Да/Нет</option>
       </select>
    </div>
    <button id="btn-add-q" class="btn btn-outline btn-block" style="margin-top:8px;">+ Добавить вопрос</button>
  </div>`;
  
  // Кнопка удаления формы
  html += `
    <div style="margin-top:40px; padding-top:20px; border-top:1px solid #333;">
      <button id="btn-del-form" class="btn btn-block" style="background:transparent; border:1px solid var(--error-color); color:var(--error-color);">
         <i data-lucide="trash" style="margin-right:8px; width:18px;"></i> Удалить форму целиком
      </button>
    </div>
  `;

  html += `</div>`;
  container.innerHTML = html;
  refreshIcons();

  // --- Слушатели Редактора ---
  document.getElementById('btn-back').onclick = renderFormsList;
  
  document.getElementById('btn-save-meta').onclick = async () => {
      await window.App.services.forms.updateFormMeta(formId, {
          title: document.getElementById('edit-title').value,
          scheduleLabel: document.getElementById('edit-time').value
      });
      renderFormEditor(formId);
  };

  document.querySelectorAll('.edit-q-label').forEach(inp => {
      inp.onchange = async () => {
          await window.App.services.forms.updateQuestion(formId, inp.dataset.qid, { label: inp.value });
      };
  });
  
  // Обработка смены типа "на лету"
  document.querySelectorAll('.q-type-selector').forEach(sel => {
      sel.onchange = async () => {
          await window.App.services.forms.updateQuestion(formId, sel.dataset.qid, { type: sel.value });
      };
  });

  document.querySelectorAll('.btn-move').forEach(b => {
      b.onclick = async () => {
          await window.App.services.forms.reorderQuestion(formId, b.dataset.qid, b.dataset.dir);
          renderFormEditor(formId);
      };
  });

  document.querySelectorAll('.btn-del').forEach(b => {
      b.onclick = async () => {
          if (confirm("Удалить вопрос?")) {
              await window.App.services.forms.deleteQuestion(formId, b.dataset.qid);
              renderFormEditor(formId);
          }
      };
  });
  
  document.getElementById('btn-add-q').onclick = async () => {
      const label = document.getElementById('new-q-text').value;
      const type = document.getElementById('new-q-type').value;
      if (label) {
          await window.App.services.forms.addQuestion(formId, { type, label });
          renderFormEditor(formId);
      }
  };
  
  document.getElementById('btn-del-form').onclick = async () => { 
      if (confirm("ВНИМАНИЕ: Удалить форму безвозвратно?")) { 
          await window.App.services.forms.deleteForm(formId); 
          renderFormsList(); 
      } 
  };
}
