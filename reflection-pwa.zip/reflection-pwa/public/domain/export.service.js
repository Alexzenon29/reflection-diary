import { STORES } from "../storage/storage.indexeddb.js";

export class ExportService {
  constructor(storage) {
    this.storage = storage;
  }

  // --- БЭКАП (JSON) ---
  async createBackupJSON() {
    const forms = await this.storage.getAll(STORES.forms);
    const entries = await this.storage.getAll(STORES.entries);
    const settings = await this.storage.getAll(STORES.settings) || [];

    const backup = {
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      forms,
      entries,
      settings
    };

    return JSON.stringify(backup, null, 2);
  }

  async restoreFromJSON(jsonString, mode = "merge") { // mode: 'merge' | 'replace'
    let data;
    try {
      data = JSON.parse(jsonString);
    } catch (e) {
      throw new Error("Невалидный JSON файл");
    }

    if (!data.forms || !data.entries) throw new Error("Неверный формат бэкапа");

    if (mode === "replace") {
      await this.storage.clear(STORES.forms);
      await this.storage.clear(STORES.entries);
      await this.storage.clear(STORES.settings);
    }

    // Восстанавливаем формы
    for (const f of data.forms) {
      await this.storage.put(STORES.forms, f);
    }

    // Восстанавливаем записи
    for (const e of data.entries) {
      await this.storage.put(STORES.entries, e);
    }
    
    // Восстанавливаем настройки
    if (data.settings) {
      for (const s of data.settings) {
        await this.storage.put(STORES.settings, s);
      }
    }
  }

  // --- ЭКСПОРТ (CSV) ---
  async createCSV() {
    const entries = await this.storage.getAll(STORES.entries);
    if (!entries.length) return "";

    // Tidy Data Format: timestamp, formTitle, questionLabel, answerValue
    const rows = [
      ["timestamp_iso", "date_local", "time_local", "form_title", "form_version", "question_id", "question_label", "answer_value"]
    ];

    entries.forEach(e => {
      const date = new Date(e.timestamp);
      const dateLocal = date.toLocaleDateString();
      const timeLocal = date.toLocaleTimeString();

      // Используем снапшоты вопросов, если они есть (для исторической точности)
      // Если снапшотов нет (старые записи), берем ответы как есть (но тогда без лейблов)
      // В нашей архитектуре мы сохраняем questionSnapshots в entries.service.js
      
      if (e.questionSnapshots) {
        e.questionSnapshots.forEach(q => {
          const val = e.answers[q.id];
          if (val !== undefined && val !== null) {
            rows.push([
              new Date(e.timestamp).toISOString(),
              dateLocal,
              timeLocal,
              e.formTitle,
              e.formVersion,
              q.id,
              q.label,
              val
            ]);
          }
        });
      }
    });

    // Конвертация в CSV строку
    return rows.map(row => 
      row.map(cell => {
        const str = String(cell);
        // Экранирование кавычек и запятых
        if (str.includes(",") || str.includes('"') || str.includes("\n")) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      }).join(",")
    ).join("\n");
  }

  downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
