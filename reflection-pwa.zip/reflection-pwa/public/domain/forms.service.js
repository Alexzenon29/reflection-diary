﻿import { STORES } from "../storage/storage.indexeddb.js";
import { uid, cloneJson } from "./utils.js";

// КОНФИГУРАЦИЯ ПО ТЗ (Золотой стандарт)
const DEFAULT_CONFIG = {
  forms: [
    {
      title: "🌅 Утро",
      scheduleLabel: "06:00 – 09:00",
      questions: [
        { type: "range", label: "Как ты спал?" },
        { type: "text", label: "Что ты чувствуешь сейчас?" },
        { type: "range", label: "Уровень энергии" },
        { type: "text", label: "Главная задача на сегодня?" },
        { type: "yesno", label: "Есть ли сопротивление к ней?" }
      ]
    },
    {
      title: "☀️ Ранний день",
      scheduleLabel: "09:00 – 11:00",
      questions: [
        { type: "text", label: "Чем занимаешься?" },
        { type: "range", label: "Ясность цели" },
        { type: "range", label: "Уровень энергии" },
        { type: "text", label: "Что ты чувствуешь сейчас?" }
      ]
    },
    {
      title: "⚡ Пик",
      scheduleLabel: "11:00 – 13:00",
      questions: [
        { type: "yesno", label: "Был ли поток?" },
        { type: "text", label: "Что мешало (помехи)?" },
        { type: "text", label: "Результат за час?" },
        { type: "text", label: "Что ты чувствуешь сейчас?" }
      ]
    },
    {
      title: "🍽️ Полдень",
      scheduleLabel: "13:00 – 15:00",
      questions: [
        { type: "text", label: "Ел ли ты? (что)" },
        { type: "text", label: "Сонливость или нервозность?" },
        { type: "range", label: "Уровень энергии" },
        { type: "text", label: "Что ты чувствуешь сейчас?" }
      ]
    },
    {
      title: "🌀 Послеобеденное",
      scheduleLabel: "15:00 – 17:00",
      questions: [
        { type: "yesno", label: "Тянет переключиться?" },
        { type: "text", label: "На что тянет?" },
        { type: "range", label: "Фокус на задаче" },
        { type: "text", label: "Что ты чувствуешь сейчас?" }
      ]
    },
    {
      title: "🌆 Вечер",
      scheduleLabel: "17:00 – 19:00",
      questions: [
        { type: "text", label: "Что сделано по факту?" },
        { type: "range", label: "Доволен прогрессом?" },
        { type: "range", label: "Уровень энергии" },
        { type: "text", label: "Что ты чувствуешь сейчас?" }
      ]
    },
    {
      title: "✅ Закрытие",
      scheduleLabel: "19:00 – 21:00",
      questions: [
        { type: "text", label: "Какая задача висит?" },
        { type: "yesno", label: "Чувство вины?" },
        { type: "text", label: "Что мешает закрыть задачу?" },
        { type: "text", label: "Что ты чувствуешь сейчас?" }
      ]
    },
    {
      title: "🌙 Перед сном",
      scheduleLabel: "21:00 – 23:00",
      questions: [
        { type: "text", label: "Главная мысль дня" },
        { type: "text", label: "Что завтра сделать иначе?" },
        { type: "range", label: "Общая оценка дня" },
        { type: "text", label: "Что ты чувствуешь сейчас?" }
      ]
    }
  ]
};

export class FormsService {
  constructor(storage) {
    this.storage = storage;
  }

  async listForms() {
    const forms = await this.storage.getAll(STORES.forms);
    return forms.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
  }

  async getForm(formId) {
    return await this.storage.get(STORES.forms, formId);
  }

  // Создание одной формы (низкоуровневое)
  async createForm({ title, scheduleLabel = "", sortOrder = 0, questions = [] }) {
    const form = {
      id: uid("f"),
      title: title?.trim() || "Новая форма",
      scheduleLabel,
      sortOrder,
      formVersion: 1,
      questions: questions.length > 0 ? questions : [
        { id: uid("q"), type: "text", label: "Новый вопрос", required: false }
      ],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await this.storage.put(STORES.forms, form);
    return form;
  }

  async duplicateForm(formId) {
    const original = await this.getForm(formId);
    if (!original) throw new Error("Form not found");
    const copy = cloneJson(original);
    copy.id = uid("f");
    copy.title = `${original.title} (Копия)`;
    copy.sortOrder = (original.sortOrder || 0) + 1;
    copy.createdAt = Date.now();
    copy.questions = copy.questions.map(q => ({ ...q, id: uid("q") }));
    await this.storage.put(STORES.forms, copy);
    return copy;
  }

  async updateFormMeta(formId, { title, scheduleLabel }) {
    const form = await this.getForm(formId);
    if (!form) return;
    form.title = title;
    form.scheduleLabel = scheduleLabel;
    form.updatedAt = Date.now();
    await this.storage.put(STORES.forms, form);
  }

  async addQuestion(formId, question) {
    const form = await this.getForm(formId);
    const q = {
      id: uid("q"),
      type: question.type,
      label: (question.label || "").trim(),
      required: !!question.required,
      ...(question.type === "range" ? { min: 1, max: 10 } : {}),
      ...(question.type === "select" ? { options: question.options ?? [] } : {})
    };
    form.questions.push(q);
    form.formVersion++;
    await this.storage.put(STORES.forms, form);
    return form;
  }

  async updateQuestion(formId, qId, newProps) {
    const form = await this.getForm(formId);
    const q = form.questions.find(x => x.id === qId);
    if (!q) return;
    Object.assign(q, newProps);
    form.formVersion++;
    await this.storage.put(STORES.forms, form);
  }

  async deleteQuestion(formId, qId) {
    const form = await this.getForm(formId);
    form.questions = form.questions.filter(x => x.id !== qId);
    form.formVersion++;
    await this.storage.put(STORES.forms, form);
  }

  async reorderQuestion(formId, qId, direction) {
    const form = await this.getForm(formId);
    const idx = form.questions.findIndex(x => x.id === qId);
    if (idx === -1) return;
    const newIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (newIdx < 0 || newIdx >= form.questions.length) return;
    [form.questions[idx], form.questions[newIdx]] = [form.questions[newIdx], form.questions[idx]];
    form.formVersion++;
    await this.storage.put(STORES.forms, form);
  }
  
  async deleteForm(formId) {
    await this.storage.delete(STORES.forms, formId);
  }

  // === НОВАЯ ФУНКЦИЯ ИМПОРТА JSON ===
  async importFromJSON(jsonData) {
    if (!jsonData || !jsonData.forms) throw new Error("Неверный формат JSON");
    
    console.log(`Импорт ${jsonData.forms.length} форм...`);
    
    let sortOrder = 1;
    for (const tmpl of jsonData.forms) {
      // Превращаем "чистые" вопросы из JSON в объекты с ID
      const questionsWithIds = (tmpl.questions || []).map(q => ({
          id: uid("q"),
          type: q.type,
          label: q.label,
          required: false,
          ...(q.type === 'range' ? { min: 1, max: 10 } : {})
      }));

      // Используем sortOrder из JSON или автоинкремент
      const order = tmpl.sortOrder || sortOrder++;

      await this.createForm({
        title: tmpl.title,
        scheduleLabel: tmpl.scheduleLabel,
        sortOrder: order,
        questions: questionsWithIds
      });
    }
  }

  // Инициализация при первом старте (или сбросе)
  async importDefaultFormsIfEmpty() {
    const existing = await this.listForms();
    if (existing.length > 0) return;
    
    console.log("База пуста. Применяю DEFAULT_CONFIG...");
    await this.importFromJSON(DEFAULT_CONFIG);
  }
}
