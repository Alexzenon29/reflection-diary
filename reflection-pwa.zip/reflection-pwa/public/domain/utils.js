export function uid(prefix = "id") {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function nowTs() {
  return Date.now();
}

export function cloneJson(obj) {
  return JSON.parse(JSON.stringify(obj));
}
