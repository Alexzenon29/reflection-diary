import { STORES } from "../storage/storage.indexeddb.js";
import { uid, nowTs, cloneJson } from "./utils.js";

export class EntriesService {
  constructor(storage, formsService) {
    this.storage = storage;
    this.formsService = formsService;
  }

  async createEntry(formId, answers, timestamp = nowTs()) {
    const form = await this.formsService.getForm(formId);
    if (!form) throw new Error("Form not found");

    const questionSnapshots = form.questions.map((q) => ({
      id: q.id,
      label: q.label,
      type: q.type,
      required: !!q.required,
      ...(q.type === "range" ? { min: q.min, max: q.max } : {}),
      ...(q.type === "select" ? { options: cloneJson(q.options ?? []) } : {})
    }));

    const entry = {
      id: uid("e"),
      formId: form.id,
      formTitle: form.title,          // удобство для экспорта/списков
      formVersion: form.formVersion,  // ключевой якорь
      timestamp,
      timezoneOffsetMin: new Date().getTimezoneOffset(),
      questionSnapshots,
      answers: cloneJson(answers ?? {})
    };

    await this.storage.put(STORES.entries, entry);
    return entry;
  }

  async getEntry(entryId) {
    return await this.storage.get(STORES.entries, entryId);
  }

  async listEntries() {
    const entries = await this.storage.getAll(STORES.entries);
    return entries.sort((a, b) => b.timestamp - a.timestamp);
  }

  async deleteEntry(entryId) {
    await this.storage.delete(STORES.entries, entryId);
  }

  async listEntriesByTimeRange(fromTs, toTs) {
    const entries = await this.storage.getEntriesByTimeRange(fromTs, toTs);
    return entries.sort((a, b) => a.timestamp - b.timestamp);
  }
}
